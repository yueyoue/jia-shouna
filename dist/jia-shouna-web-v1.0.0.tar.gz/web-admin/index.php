<?php
/**
 * Web管理后台入口 - 路由分发
 */
session_start();

// 检查是否已安装
if (!file_exists(__DIR__ . '/../install.lock') && basename($_SERVER['SCRIPT_FILENAME']) !== 'install.php') {
    header('Location: install.php');
    exit;
}

require_once __DIR__ . '/../backend/config/database.php';

// 检查登录状态(管理后台用Session)
$publicPages = ['login'];
$page = $_GET['p'] ?? 'dashboard';
$isLoginPage = in_array($page, $publicPages);

if (!$isLoginPage && empty($_SESSION['admin_id'])) {
    header('Location: index.php?p=login');
    exit;
}

// 页面路由映射
$pages = [
    'login' => 'pages/login.php',
    'dashboard' => 'pages/dashboard.php',
    'spaces' => 'pages/spaces.php',
    'items' => 'pages/items.php',
    'api-config' => 'pages/api-config.php',
    'backup' => 'pages/backup.php',
    'users' => 'pages/users.php',
    'settings' => 'pages/settings.php',
    'version' => 'pages/version.php',
];

$pageFile = $pages[$page] ?? null;
if (!$pageFile || !file_exists(__DIR__ . '/' . $pageFile)) {
    $page = 'dashboard';
    $pageFile = $pages['dashboard'];
}

// 登录页不包含布局
if ($isLoginPage) {
    require __DIR__ . '/' . $pageFile;
    exit;
}

// 获取管理员信息
$adminUser = null;
if (isset($_SESSION['admin_id'])) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM sys_user WHERE id = ? AND role = 1 AND status = 1");
    $stmt->execute([$_SESSION['admin_id']]);
    $adminUser = $stmt->fetch();
}
if (!$adminUser) {
    session_destroy();
    header('Location: index.php?p=login');
    exit;
}

// 包含布局和页面
require __DIR__ . '/layout.php';
